const mongoose = require("mongoose");
const express = require("express");
const app = express();
const port = 3300;
app.use(express.static(__dirname));
app.use("/images", express.static("images"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
mongoose
  .connect("mongodb://127.0.0.1:27017/ArtGallery")
  .then(() => console.log("Connection successful"))
  .catch((err) => {
    console.log("Error in connection" + err.stack);
    process.exit(1);
  });
const userLogin = mongoose.model(
  "user",
  new mongoose.Schema(
    {
      name: String,
      email: String,
      password: String,
      dob: String,
      gender: String,
      contact: String,
    },
    {
      collection: "userdetails",
    }
  )
);
const userContacts = mongoose.model(
  "contact",
  new mongoose.Schema(
    {
      name: String,
      email: String,
      mobile: String,
      message: String,
    },
    {
      collection: "contacts",
    }
  )
);
const userOrders = mongoose.model(
  "order",
  new mongoose.Schema(
    {
      name: String,
      mobile: String,
      shipping_address: String,
    },
    {
      collection: "userorders",
    }
  )
);
app.post("/registration", async (req, res) => {
  const { name, email, password, dob, gender, contact } = req.body;
  try {
    const existingUser = await userLogin.findOne({ email });
    if (!existingUser) {
      await userLogin.create({ name, email, password, dob, gender, contact });
      res.redirect("/login");
    } else {
      return res.send("User already exists");
    }
  } catch (error) {
    console.error("Failed to register", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await userLogin.findOne({ email, password });
    if (!user) {
      return res.send("Invalid User");
    } else {
      res.redirect("/access");
    }
  } catch (error) {
    console.error("Failed to Login", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.post("/contacts", async (req, res) => {
  const { name, email, mobile, message } = req.body;
  try {
    const contact = new userContacts({ name,  email, mobile,  message });
    await contact.save();
    res.redirect("/access"); 
  } catch (error) {
    console.error("Failed to save contact", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.post("/order", async (req, res) => {
  const { name, mobile, shipping_address } = req.body;
  try {
    const contact = new userOrders({ name, mobile,  shipping_address });
    await contact.save();
    res.redirect("/access"); 
  } catch (error) {
    console.error("Failed to save contact", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/home.html");
});

app.get("/access", (req, res) => {
  res.sendFile(__dirname + "/access.html");
});

app.get("/about", (req, res) => {
  res.sendFile(__dirname + "/about.html");
});

app.get("/contact", (req, res) => {
  res.sendFile(__dirname + "/contact.html");
});

app.get("/products", (req, res) => {
  res.sendFile(__dirname + "/shop.html");
});

app.get("/login", (req, res) => {
  res.sendFile(__dirname + "/login.html");
});

app.get("/services", (req, res) => {
  res.sendFile(__dirname + "/services.html");
});

app.get("/registration", (req, res) => {
  res.sendFile(__dirname + "/register.html");
});

app.get("/booking_page", (req, res) => {
  res.sendFile(__dirname + "/Account.html");
});

app.listen(port, () =>
  console.log(`Server is running at http://localhost:${port}`)
);
